"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

type CartItem = {
  nome: string
  preco: number
}

export default function TudoParaNamorados() {
  const [carrinho, setCarrinho] = useState<CartItem[]>([])

  function adicionarAoCarrinho(nome: string, preco: number) {
    setCarrinho([...carrinho, { nome, preco }])
  }

  function removerItem(index: number) {
    const novoCarrinho = [...carrinho]
    novoCarrinho.splice(index, 1)
    setCarrinho(novoCarrinho)
  }

  function calcularTotal() {
    return carrinho.reduce((soma, item) => soma + item.preco, 0)
  }

  return (
    <div className="min-h-screen bg-pink-50 text-red-900">
      {/* Header */}
      <header className="bg-red-100 p-6 text-center shadow-md">
        <h1 className="text-4xl font-bold">TudoParaNamorados</h1>
        <p className="text-lg">Presentes românticos que dizem tudo ❤️</p>
      </header>

      {/* Página Inicial */}
      <section className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Destaques da Semana</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-white">
            <CardContent className="p-4">
              <img
                src="/images/cesta-romantica.png"
                alt="Cesta Romântica"
                className="rounded-xl mb-4 w-full h-48 object-cover"
              />
              <h3 className="text-xl font-bold">Cesta Amor Doce</h3>
              <p className="text-sm text-gray-600">Buquê, chocolates e pelúcia fofa.</p>
              <p className="text-lg font-bold mt-2">R$ 99,99</p>
              <Button className="mt-3 w-full" onClick={() => adicionarAoCarrinho("Cesta Amor Doce", 99.99)}>
                Adicionar ao Carrinho
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Página de Produto */}
      <section className="p-6 bg-white mt-8">
        <h2 className="text-2xl font-semibold mb-4">Detalhes do Produto</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <img src="/images/cesta-romantica.png" alt="Produto" className="rounded-xl w-full h-80 object-cover" />
          <div>
            <h3 className="text-xl font-bold mb-2">Cesta Amor Doce</h3>
            <p className="mb-2">
              Uma linda cesta com buquê, pelúcia (Stitch ou ursinho) e chocolates (Ferrero, BIS, Garoto, etc).
            </p>
            <p className="mb-2">Inclui embalagem romântica e laço decorativo.</p>
            <label className="block mb-2">Mensagem personalizada:</label>
            <textarea className="w-full p-2 border rounded-md mb-4" placeholder="Digite sua mensagem..." />
            <p className="text-lg font-bold mb-2">R$ 99,99</p>
            <Button onClick={() => adicionarAoCarrinho("Cesta Amor Doce", 99.99)}>Adicionar ao Carrinho</Button>
          </div>
        </div>
      </section>

      {/* Carrinho de Compras */}
      <section className="mt-12 bg-white p-6 rounded-xl shadow mx-6">
        <h2 className="text-2xl font-semibold mb-4">🛒 Seu Carrinho</h2>
        {carrinho.length === 0 ? (
          <div className="mb-4 p-4 border rounded-lg">
            <p className="text-gray-600">Seu carrinho está vazio. Adicione produtos para continuar!</p>
          </div>
        ) : (
          <ul className="mb-4">
            {carrinho.map((item, index) => (
              <li key={index} className="flex justify-between items-center mb-2 p-2 border-b">
                <span>{item.nome}</span>
                <div className="flex gap-2 items-center">
                  <span>R$ {item.preco.toFixed(2)}</span>
                  <button
                    onClick={() => removerItem(index)}
                    className="text-red-600 h-6 w-6 flex items-center justify-center rounded-full hover:bg-red-100"
                  >
                    ✕
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}

        <p className="text-lg font-bold">Total: R$ {calcularTotal().toFixed(2)}</p>

        <div className="mt-4">
          <a
            href="https://mpago.li/1TjWkrD"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition inline-block"
          >
            💳 Pagar com Mercado Pago
          </a>
        </div>
      </section>

      {/* Página de Contato */}
      <section className="p-6 bg-red-50 mt-8 text-center">
        <h2 className="text-2xl font-semibold mb-4">Fale Conosco</h2>
        <p className="mb-2">Atendimento rápido e com carinho ❤️</p>
        <a
          href="https://instagram.com/tudoparanamorados.ofc"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-xl shadow hover:from-purple-600 hover:to-pink-600"
        >
          📱 Seguir no Instagram
        </a>
      </section>

      {/* Rodapé */}
      <footer className="text-center p-4 text-sm text-gray-600 mt-8">
        © 2025 TudoParaNamorados. Todos os direitos reservados.
      </footer>
    </div>
  )
}
